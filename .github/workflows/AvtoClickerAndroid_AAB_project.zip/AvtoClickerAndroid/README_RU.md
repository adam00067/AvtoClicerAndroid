# Авто Кликер — Android проект

Готовый Android Studio проект-обёртка для игры «Авто Кликер».

## Что внутри
- Android applicationId: `com.avtokliker.game`
- compileSdk 36
- targetSdk 36
- minSdk 23
- Java 17
- WebView с локальным `index.html`
- включено JavaScript и DOM Storage
- прогресс игры сохраняется через localStorage
- иконка приложения добавлена

## Как получить AAB
1. Установи Android Studio.
2. Открой папку `AvtoClickerAndroid` как проект.
3. Дождись синхронизации Gradle и установки Android SDK 36.
4. Выбери **Build → Generate Signed App Bundle / APK**.
5. Выбери **Android App Bundle**.
6. Создай или выбери keystore.
7. Собери `release`.
8. Полученный файл `.aab` загружается в Google Play Console.

Для нового приложения Google Play с 31 августа 2026 года требует target API 36 или выше.

## Важно про рекламу
HTML сейчас содержит интеграцию рекламы Яндекс Игр. Она рассчитана на среду Яндекс Игр и не является мобильной рекламной интеграцией Google Play-приложения. Для монетизации Android-версии рекламный SDK нужно подключить отдельно.
